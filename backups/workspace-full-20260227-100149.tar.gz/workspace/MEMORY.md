# OpenClaw Memory Design

> Memory architecture, compaction strategy, and flush rules.
> Location: ~/openclaw/workspace/MEMORY.md

## Architecture

```
~/openclaw/workspace/memory/
├── context/          # Current session context (auto-managed)
├── long-term/        # Persistent facts, decisions, patterns
│   ├── projects.md   # Project-level knowledge
│   ├── contacts.md   # Key contacts and relationships
│   ├── decisions.md  # Architectural and business decisions
│   └── patterns.md   # Recurring patterns and solutions
├── short-term/       # Session scratchpad (compacted regularly)
│   └── session.md    # Current session notes
└── index.md          # Memory index and search hints
```

## Compaction Strategy

| Setting | Value | Rationale |
|---------|-------|-----------|
| Mode | `safeguard` | Prevents accidental context loss |
| Trigger | End of session or context > 80% | Flush before overflow |
| Action | Summarize key facts to long-term, clear short-term | Keep long-term lean |
| Max short-term size | 50KB | Force compaction at threshold |

## Memory Flush Rules

### What to persist (long-term)
- Business decisions and their rationale
- Project status changes
- Contact information and preferences
- Error patterns and their solutions
- Configuration changes and why they were made

### What to discard (short-term only)
- Intermediate reasoning steps
- Raw API responses
- Temporary file paths
- One-time debugging output
- Session-specific context

## Flush Prompt

At end of each session, the agent should:

1. Review short-term memory for items matching "persist" criteria
2. Append qualifying items to the appropriate long-term file
3. Clear short-term memory
4. Update index.md with new entries
5. Log flush action to audit trail

## Search

- **Provider**: Local file search (no external vector DB for now)
- **Index**: SQLite-backed FTS via `openclaw memory index`
- **Reindex**: Run after any long-term memory update

## Future: External Backends

When budget allows, consider:
- **Mem0**: For structured entity memory across sessions
- **QMD**: For queryable markdown documents with embeddings

For now, local markdown files + SQLite FTS is sufficient and free.
