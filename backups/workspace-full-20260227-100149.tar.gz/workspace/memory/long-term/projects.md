# Projects\n\n> Project-level knowledge and status.\n\n| Project | Status | Notes |\n|---------|--------|-------|\n| OpenClaw Setup | In progress | WSL2 hardened install |
