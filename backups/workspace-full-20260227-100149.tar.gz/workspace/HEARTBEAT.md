# OpenClaw Heartbeat System

> Cheap, effective monitoring on a 30-60 minute interval.
> Location: ~/openclaw/workspace/HEARTBEAT.md

## Strategy

- **Model**: Always `gpt-4o-mini` (cheapest tier)
- **Max tokens per check**: 100
- **Interval**: 30 minutes (configurable)
- **Noise level**: Low — only report anomalies, suppress OK status
- **Notification hours**: 8am–6pm Central (defer outside work hours)

## Heartbeat Tasks

### 1. OpenClaw Self-Health
| Field | Value |
|-------|-------|
| Check | Gateway alive, memory reachable, workspace writable |
| Command | `openclaw status --json` |
| Alert if | Status != "ok" or any subsystem degraded |
| Frequency | Every 30 min |

### 2. Docker Status
| Field | Value |
|-------|-------|
| Check | Docker daemon running, no containers in restart loop |
| Command | `docker info --format '{{.ServerVersion}}'` |
| Alert if | Docker unreachable or container restart count > 3 |
| Frequency | Every 30 min |

### 3. Disk Space
| Field | Value |
|-------|-------|
| Check | Available disk on / and /home |
| Command | `df -h / /home --output=pcent | tail -n+2` |
| Alert if | Usage > 85% |
| Frequency | Every 60 min |

### 4. Security Monitor
| Field | Value |
|-------|-------|
| Check | Run security-monitor.sh and check for CRITICAL findings |
| Command | `bash ~/openclaw/scripts/security-monitor.sh` |
| Alert if | Any CRITICAL-level finding |
| Frequency | Every 60 min |

### 5. Log Rotation
| Field | Value |
|-------|-------|
| Check | Log directory sizes, run rotation if needed |
| Command | `du -sh ~/openclaw/logs/` |
| Alert if | Total logs > 100MB |
| Frequency | Every 60 min |

### 6. Memory Compaction Check
| Field | Value |
|-------|-------|
| Check | Short-term memory size vs threshold |
| Command | `du -sb ~/openclaw/workspace/memory/short-term/` |
| Alert if | Size > 50KB (trigger compaction) |
| Frequency | Every 60 min |

## Alert Routing

| Severity | Action |
|----------|--------|
| CRITICAL | Log + queue notification for next work hour |
| WARNING | Log only (review during daily summary) |
| INFO | Suppress (available in logs if needed) |

## Heartbeat Script

The heartbeat runner lives at `~/openclaw/scripts/heartbeat.sh`.
It iterates through the tasks above, runs each check, and logs results.

### Execution Model

```
crontab entry:
*/30 * * * * /home/ales/openclaw/scripts/heartbeat.sh >> /home/ales/openclaw/logs/audit/heartbeat.log 2>&1
```

### Budget Impact

- 6 checks per heartbeat run
- ~50 tokens per check (model summarizes result)
- 48 runs/day at 30-min interval
- **Estimated daily cost**: ~14,400 tokens/day = negligible on $20 plan
- Heartbeat checks run locally (shell commands), model only used for anomaly summarization

## Quiet Mode

When all checks pass:
- Log single line: `[timestamp] heartbeat OK (6/6 checks passed)`
- No model invocation needed
- Only invoke model when anomaly detected (saves tokens)

## Future Enhancements

- n8n webhook integration for push notifications
- Daily digest email via GHL automation
- Trend analysis on disk/memory usage over time
