# OpenClaw Agents & Model Routing

> Sub-agent definitions and model routing strategy for $20 ChatGPT/Codex plan.
> Location: ~/openclaw/workspace/AGENTS.md

## Model Routing Strategy

### Budget: $20/mo ChatGPT Plus / Codex Plan

The $20 plan includes access to GPT-4o, GPT-4o-mini, and Codex models.
Route tasks to the cheapest capable model to maximize throughput.

### Tiered Model Usage

| Tier | Model | Use For | Cost Impact |
|------|-------|---------|-------------|
| **Premium** | gpt-4o | Complex reasoning, code review, architecture decisions | High — use sparingly |
| **Standard** | gpt-4o-mini | General tasks, summarization, formatting, data extraction | Low — default tier |
| **Heartbeat** | gpt-4o-mini | Health checks, status polls, routine monitoring | Minimal — keep queries tiny |

### Routing Rules

1. **Default**: Route to `gpt-4o-mini` unless task complexity requires premium
2. **Escalation**: Auto-escalate to `gpt-4o` if mini fails or task involves:
   - Multi-step reasoning chains
   - Code generation > 50 lines
   - Security-sensitive decisions
   - Architecture or design work
3. **Heartbeats**: Always `gpt-4o-mini` with max 100 tokens per check
4. **Fallback**: If primary model is rate-limited, queue and retry after 60s

## Sub-Agent Definitions

### researcher
| Field | Value |
|-------|-------|
| Role | Web research and data gathering |
| Model | gpt-4o-mini (default) |
| Tools | browser, read |
| Sandbox | Yes |
| Max concurrent | 2 |

### coder
| Field | Value |
|-------|-------|
| Role | Code generation and editing |
| Model | gpt-4o (premium — code quality matters) |
| Tools | read, write, edit, exec |
| Sandbox | Yes |
| Max concurrent | 1 |

### reviewer
| Field | Value |
|-------|-------|
| Role | Code review and security audit |
| Model | gpt-4o (premium — security matters) |
| Tools | read |
| Sandbox | Yes |
| Max concurrent | 1 |

### monitor
| Field | Value |
|-------|-------|
| Role | Heartbeat and health monitoring |
| Model | gpt-4o-mini (cheapest tier) |
| Tools | read, exec |
| Sandbox | Yes |
| Max concurrent | 1 |

## Concurrency Limits

| Setting | Value |
|---------|-------|
| Max concurrent agents | 4 |
| Max concurrent sub-agents | 8 |
| Heartbeat interval | 30 min |
| Queue overflow action | Log warning, defer to next interval |
