# RESOURCES.md — Project-1 Available Resources

> **SECURITY NOTE:** This file contains ONLY handles, identifiers, and platform names.
> Passwords, API keys, tokens, OAuth credentials, and any other secrets are NEVER stored here.
> Credentials are saved in the Chrome browser profile on Linux. Agents access platforms through Chrome.

## Email Accounts

| Platform | Address                       | Access Method           |
|----------|-------------------------------|-------------------------|
| Gmail    | tejasstar001@gmail.com        | Chrome on Linux (logged in, password saved) |
| Outlook  | tejasstar001@outlook.com      | Chrome on Linux (logged in, password saved) |

## Social Media Accounts

| Platform   | Linked To                     | Access Method           |
|------------|-------------------------------|-------------------------|
| LinkedIn   | tejasstar001@gmail.com        | Chrome on Linux (logged in) |
| Facebook   | tejasstar001@outlook.com      | Chrome on Linux (logged in) |
| X (Twitter)| gmail or outlook (linked)     | Chrome on Linux (logged in) |
| Instagram  | gmail or outlook (linked)     | Chrome on Linux (logged in) |

## Communication

| Platform  | Handle                        | Purpose                 |
|-----------|-------------------------------|-------------------------|
| Telegram  | @Aravbbot                     | Owner ↔ team comms |

## Browser Environment
- **Chrome on Linux (WSL2 Ubuntu-24.04)** — the same Chrome instance installed and connected to OpenClaw during setup (Section A)
- OpenClaw OAuth authentication is completed through this browser (localhost:1455 callback)
- All accounts listed above are logged in with passwords saved in the browser profile
- Agents interact with platforms through this OpenClaw-connected Chrome instance
- No separate credential entry needed — sessions are active in the browser profile
- Chrome data directory: `~/openclaw/chrome-data/`

## Infrastructure

| Service  | Details                                      | Status        |
|----------|----------------------------------------------|---------------|
| Vercel   | Owner configures projects on request         | Available     |
| Stripe   | Owner configures API keys on request         | Available     |

## Owner's Existing Stack (Leverage Points)

| Tool / Platform       | Relevance                                    |
|-----------------------|----------------------------------------------|
| GoHighLevel (GHL)     | CRM, funnels, workflows, calendars           |
| n8n                   | Workflow automation, integrations            |
| PowerShell            | Windows automation, scripting                |
| OpenClaw              | AI agent orchestration framework             |
| MyAssistant365.ai     | Existing AI assistant product/brand          |
| FlowGrant.ai          | Existing automation/grants brand             |

## How to Request a New Resource
1. CEO identifies the need and purpose
2. CEO submits request to owner via Telegram with: resource name, why it's needed, expected cost (if any)
3. Owner provisions and provides handle/identifier — secrets stay in browser/vault
4. Update this file with the new handle/identifier (never the secret)
