# Memory Index

> Auto-generated index for OpenClaw memory search.

## Long-term
- projects.md — Project-level knowledge
- contacts.md — Key contacts and relationships
- decisions.md — Architectural and business decisions
- patterns.md — Recurring patterns and solutions

## Short-term
- session.md — Current session scratchpad
