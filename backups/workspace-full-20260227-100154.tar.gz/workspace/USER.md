# OpenClaw User Profile

> Owner preferences and context for agent personalization.
> Location: ~/openclaw/workspace/USER.md

## Owner

| Field | Value |
|-------|-------|
| Name | Rashmi Sheel |
| Primary Org | CMIT Solutions of Sugar Land |
| Secondary Orgs | MyAssistant365.ai, FlowGrant.ai |
| Role | Owner / Operator |
| Location | Sugar Land, TX |

## Business Context

- **CMIT Solutions**: Managed IT services (MSP) for small/medium businesses
- **MyAssistant365.ai**: AI automation platform for SMBs
- **FlowGrant.ai**: Grant writing automation (in development)

## Tech Stack

| Category | Tool |
|----------|------|
| CRM | GoHighLevel (3 sub-accounts) |
| Automation | n8n (self-hosted) + PowerShell |
| Email | GoDaddy-hosted Microsoft 365 |
| AI Models | ChatGPT $20 plan (Codex) for OpenClaw; Claude for development |
| OS | Windows 11 Pro + WSL2 (Ubuntu 24.04) |
| Browser | Google Chrome (WSLg for OpenClaw) |
| Version Control | Git |

## GHL Location IDs

- MA365: `TRCNNuDrXPsF4rw5Zcem`
- CMIT: `0tQxNGqAUJh6eU2fCcX6`
- FBFP: `mC7bzAQjL2wCeketbVKs`

## Preferences

- Commercial products with professional installers over DIY
- Concise communication — bullet points over paragraphs
- Security-conscious — always confirm before destructive ops
- Budget-conscious — optimize for $20/mo AI spend
- Prefers structured output (tables, lists, code blocks)
- No emojis unless explicitly requested

## Working Hours

- Central Time (US/Central)
- Primary work: weekdays
- Agent can run heartbeats 24/7 but defer notifications to work hours

## Communication Channels

- Primary: CLI / terminal
- Secondary: n8n webhook notifications
- No chat channel integrations (Telegram/Discord/Slack disabled)
